Estos son los apuntes de hoy que he tomado de la clase de programacion orientada a objetos y bases de datos relacionales.

Desarrolla brevemente los conceptos y genera snipets de codigo sencillos cuando lo veas apropiado.

Copiare lo que generes en un .md en obsidian. 

Los snipets de codigo de java generalos asi:

´´´java
codigo
´´´´