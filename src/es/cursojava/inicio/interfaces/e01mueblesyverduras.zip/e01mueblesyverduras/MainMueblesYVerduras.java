package es.cursojava.inicio.interfaces.e01mueblesyverduras;

public class MainMueblesYVerduras {

	public static void main(String[] args) {

		Inicializaciones.runMueblesYVerduras();

	}
}
