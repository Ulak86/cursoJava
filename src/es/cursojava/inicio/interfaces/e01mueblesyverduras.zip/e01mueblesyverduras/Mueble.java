package es.cursojava.inicio.interfaces.e01mueblesyverduras;

public abstract class Mueble implements Limpiable {

	private String color;

	public Mueble(String color) {
		this.color = color;
	}

}
