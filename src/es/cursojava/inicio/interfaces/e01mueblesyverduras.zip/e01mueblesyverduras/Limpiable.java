package es.cursojava.inicio.interfaces.e01mueblesyverduras;

public interface Limpiable {

	void limpiar();

}
