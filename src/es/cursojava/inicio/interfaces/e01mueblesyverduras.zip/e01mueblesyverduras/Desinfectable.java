package es.cursojava.inicio.interfaces.e01mueblesyverduras;

public interface Desinfectable extends Limpiable {

	void desinfectar();

}
