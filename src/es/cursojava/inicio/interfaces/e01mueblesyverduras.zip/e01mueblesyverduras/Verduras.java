package es.cursojava.inicio.interfaces.e01mueblesyverduras;

public abstract class Verduras implements Desinfectable {

	private String origen;

	public Verduras(String origen) {
		this.origen = origen;
	}

}
